<?php
$connection = mysqli_connect('localhost','root','','test') or die(mysqli_error($connection));
?>