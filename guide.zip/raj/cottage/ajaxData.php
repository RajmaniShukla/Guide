<html>
    <head>
        <?php
require('dbconfig.php');

?>
        <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
</head>
     <link rel="stylesheet" href="../style1.css">
        <?php
include 'dbConfig.php';
if(!empty($_POST["district_id"])){
    $s=$_POST['district_id'];
    $query = $db->query("SELECT * FROM cottage WHERE district_id = ".$s." AND status = 1");
    $rowCount = $query->num_rows;
    if($rowCount > 0){
        echo '<div value="">    </div>';
        while($row = $query->fetch_assoc()){ 
            echo '<form action="profile_c.php" method="POST"><div class="col-md-3"><div  style="border:1px solid #ccc; padding:20px; margin-bottom:20px;" value="'.$row['cottage_id'].'"><b>'.$row['cottage_name'].'</b><br><div class="more">'.$row['cottage_desc'].'</div><br>'.$row['cottage_price'].'<br></div></div></form>';
            ?>
            <a href="profile_c.php?id=<?php echo $row['cottage_id'];?>"><button>BOOK NOW</button></a>
    <?php
        }    
    }
    else   {
        echo '<div value="">hotel not available</div>';
    }
    }
    
?>
 
    
    <script>
      
$(document).ready(function() {
	var showChar = 200;
	var ellipsestext = "";
	var moretext = "more";
	var lesstext = "less";
	$('.more').each(function() {
		var content = $(this).html();
		if(content.length > showChar) {
			var c = content.substr(0, showChar);
			var h = content.substr(showChar-1, content.length - showChar);
			var html = c + '<span class="moreelipses">'+ellipsestext+'</span>&nbsp;<span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">'+moretext+'</a></span>';
			$(this).html(html);
		}

	});
	$(".morelink").click(function(){
		if($(this).hasClass("less")) {
			$(this).removeClass("less");
			$(this).html(moretext);
		} else {
			$(this).addClass("less");
			$(this).html(lesstext);
		}
		$(this).parent().prev().toggle();
		$(this).prev().toggle();
		return false;
	});
});      
</script>
</html>