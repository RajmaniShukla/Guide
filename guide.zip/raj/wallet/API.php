<?php
	function gateway($work,$rs){
		if($work = "credit"){
			return 1;
		}else if($work = "debit"){
			return 1;
		}
	}
?>