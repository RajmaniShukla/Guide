<?php
$db_name1 = "test";
$mysql_username = "root";
$mysql_password = "";
$server_name = "localhost";
$conn1 = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name1);
?>